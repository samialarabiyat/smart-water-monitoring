
import streamlit as st
import requests
import pandas as pd

st.set_page_config(page_title="Smart Water Flow Monitor", layout="wide")
st.title("💧 Real-Time Water Flow Dashboard")

firebase_url = "https://your-project-id.firebaseio.com/flowData.json"

if st.button("🔄 Refresh Now"):
    response = requests.get(firebase_url)
    if response.status_code == 200:
        data = response.json()

        if isinstance(data, dict):
            df = pd.DataFrame(data).T
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df = df.sort_values("timestamp")

            st.subheader("📈 Water Flow Over Time")
            st.line_chart(df.set_index("timestamp")["flow"])

            st.subheader("📋 Recent Readings")
            st.dataframe(df.tail(10))
        else:
            st.warning("No valid data found in Firebase.")
    else:
        st.error("Failed to retrieve data from Firebase.")
else:
    st.info("Click 'Refresh Now' to load data.")
